from enum import Enum
import numpy as np

from CreateMethod import *
from Gender import *
from GiantPanda import *
from _const import *


class GiantPandaGenerator:
    def __init__(self, min_age=MIN_AGE, max_age=MAX_AGE):
        self.min_age = min_age
        self.max_age = max_age
        self.init_observed_age_distribution()

    def init_observed_age_distribution(self):
        age_list = np.arange(MAX_AGE+1)

        available_age_list = np.arange(MIN_AGE, MAX_AGE+1)
        prob_sum = 0
        for i in age_list:
            if i in available_age_list:
                prob_sum += TOTAL_AGE_PROB_MAP[i]
                
        self.observed_age_distribution = np.zeros(len(age_list))
        for pos, i in enumerate(age_list):
            if i in available_age_list:
                current_prob = TOTAL_AGE_PROB_MAP[i]/float(prob_sum)
            else:
                current_prob = 0.0
            if pos == 0:
                self.observed_age_distribution[pos] = current_prob
            else:
                self.observed_age_distribution[pos] = self.observed_age_distribution[pos-1] + current_prob

    def get_age_from_distribution(self, distribution_list, value):
        for i, accumulated_prob in enumerate(distribution_list):
            if value < accumulated_prob:
                return i
        return len(distribution_list)-1

    def generate(self, method=CreateMethod.baby, age=0, gender=Gender.male):
        if method == CreateMethod.baby:
            return GiantPanda(age=0, gender=random_gender())
        elif method == CreateMethod.random:
            age = random.randint(self.min_age, self.max_age)
            return GiantPanda(age=age, gender=random_gender())
        elif method == CreateMethod.normal:
            # a = random.randint(10000)
            a = np.random.choice(x, size=1, p=prob)
            age = a[0] + (MAX_AGE - MIN_AGE) / 2
            return GiantPanda(age=age, gender=random_gender())
        elif method == CreateMethod.given:
            age = self.get_age_from_distribution(self.observed_age_distribution, random.random())
            return GiantPanda(age=age, gender=random_gender())
        else:
            return GiantPanda(age=age, gender=gender)

    def set_min_age(self, min_age):
        self.min_age = min_age

    def set_max_age(self, max_age):
        self.max_age = max_age