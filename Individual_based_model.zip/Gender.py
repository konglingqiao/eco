from enum import Enum
import random

class Gender(Enum):
    male = 1
    female = 2


def random_gender():
    gender_id = random.randint(1, 2)
    if gender_id == 1:
        return Gender.male
    else:
        return Gender.female