from GiantPandaGenerator import *
import numpy as np

from _const import *

class Population:
    def __init__(self, individuals):
        self.individuals = individuals


    def check_extinction(self):
        if len(self.individuals) <= 1:
            return True

        male_min_age = 25
        female_min_age = 25
        male_count = 0
        female_count = 0
        for individual in self.individuals:
            if individual.gender == Gender.male and individual.age < male_min_age:
                male_min_age = individual.age
                male_count += 1
            if individual.gender == Gender.female and individual.age < female_min_age:
                female_min_age = individual.age
                female_count += 1
        # if female_min_age > MAX_FEMALE_BEARING_AGE or male_min_age > MAX_MALE_BEARING_AGE:
        #     return True

        if male_count < 1 or female_count < 1:
            return True

        if female_min_age > MAX_FEMALE_BEARING_AGE:
            return True

        return False

    def next_year(self):
        dead_ids = []
        for i, individual in enumerate(self.individuals):
            if not self.get_survivor(individual.age):
                dead_ids += [i]
        if len(dead_ids) > 0:
            self.individuals = list(np.delete(self.individuals, dead_ids))

        for i, individual in enumerate(self.individuals):
            self.individuals[i].age += 1

        new_individuals = []
        generator = GiantPandaGenerator()

        if not self.check_extinction():
            for individual in self.individuals:
                if individual.gender == Gender.female:
                    if self.get_fecundity(individual.age):
                        new_individuals += [generator.generate(method=CreateMethod.baby)]
            self.individuals += list(new_individuals)

    def get_female_count(self):
        female_count = 0
        for individual in self.individuals:
            if individual.gender == Gender.female:
                female_count += 1
        return female_count

    def get_male_count(self):
        male_count = 0
        for individual in self.individuals:
            if individual.gender == Gender.male:
                male_count += 1
        return male_count

    def get_age_struct(self):
        age_struct = np.zeros(27)
        for individual in self.individuals:
            age_struct[individual.age] += 1
        return age_struct

    def get_gender_struct(self):
        gender_struct = np.zeros(2)
        female_count = self.get_female_count()
        male_count = self.get_male_count()
        gender_struct[0] = male_count
        gender_struct[1] = female_count
        return gender_struct

    def get_survivor_rate(self, age):
        if age < 0 or age > MAX_AGE:
            return 0
        else:
            return SURVIVOR_RATE_MAP[age]

    def get_survivor(self, age):
        survivor_rate = self.get_survivor_rate(age)
        if random.random() > 1-(1-survivor_rate)*1.0:
            return False
        return True

        if age < 0 or age > 26:
            return False

        survivor_rate = SURVIVOR_RATE_MAP[age]
        if random.random() > 1-(1-survivor_rate)*1.0:
            return False

        return True

    def get_fecundity(self, age):
        if age < 0 or age > 25:
            return False

        fecundity_rate = FECUNDITY_RATE_MAP[age]
        if random.random() > fecundity_rate:
            return False

        return True