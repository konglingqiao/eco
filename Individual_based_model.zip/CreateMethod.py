from enum import Enum

class CreateMethod(Enum):
    baby = 1
    random = 2
    normal = 3
    given = 4