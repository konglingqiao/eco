import copy
import numpy as np
from tqdm import tqdm
import pandas as pd
from _const import *
from Population import *

age_list = np.arange(MAX_AGE+1)
prob_sum = 0
for i in age_list:
    prob_sum += TOTAL_AGE_PROB_MAP[i]
total_age_distribution = np.zeros(len(age_list))
for pos, i in enumerate(age_list):
    if pos == 0:
        total_age_distribution[pos] = TOTAL_AGE_PROB_MAP[i]/float(prob_sum)
    else:
        total_age_distribution[pos] = total_age_distribution[pos-1] + TOTAL_AGE_PROB_MAP[i]/float(prob_sum)


def get_age_from_distribution(distribution_list, value):
    for i, accumulated_prob in enumerate(distribution_list):
        if value < accumulated_prob:
            return i
    return len(distribution_list)-1


def population_simulation(population, max_year=100, b_print=False):
    population_list = [copy.deepcopy(population)]
    for i in range(max_year-1):
        population.next_year()
        population_list += [copy.deepcopy(population)]

    if b_print:
        for i, pop in enumerate(population_list):
            print('Year #{}-- male:{}, female:{}'.format(i+1, pop.get_male_count(), pop.get_female_count()))
        if population_list[-1].check_extinction():
            print('Extincted.')

    male_count_list = [pop.get_male_count() for pop in population_list]
    female_count_list = [pop.get_female_count() for pop in population_list]
    extincted_list = [population.check_extinction() for population in population_list]
    age_struct_list = [pop.get_age_struct() for pop in population_list]
    gender_struct_list = [pop.get_gender_struct() for pop in population_list]
    return male_count_list, female_count_list, extincted_list, age_struct_list, gender_struct_list


def test(start_pop_num=3, test_time=100, max_year=100, b_print=False):
    generator = GiantPandaGenerator()
    individuals = []
    baby_count = int(round(start_pop_num/(1-total_age_distribution[0])*total_age_distribution[0]))
    for i in range(baby_count):
        individuals += [generator.generate(method=CreateMethod.baby)]

    for i in range(start_pop_num):
        individuals += [generator.generate(method=CreateMethod.given)]

    if b_print:
        for i, individual in enumerate(individuals):
            str_gender = 'male'
            if individual.gender == Gender.female:
                str_gender = 'female'
            print('Individual #{}: [gender-{}] [age-{}]'.format(i+1, str_gender, individual.age))


    pop0 = Population(individuals)
    total_male_count_array = np.zeros(max_year)
    total_female_count_array = np.zeros(max_year)
    total_extinct_rate_array = np.zeros(max_year)
    total_age_struct_array = None
    total_gender_struct_array = None
    for i in range(test_time):
        pop = copy.deepcopy(pop0)
        male_count_list, female_count_list, extincted_list, age_struct_list, gender_struct_list = population_simulation(pop, max_year=max_year, b_print=False)
        total_male_count_array += np.array(male_count_list)
        total_female_count_array += np.array(female_count_list)
        total_extinct_rate_array += np.array(extincted_list)
        if total_age_struct_array is None:
            total_age_struct_array = np.asarray(age_struct_list)
        else:
            total_age_struct_array += np.asarray(age_struct_list)
        if total_gender_struct_array is None:
            total_gender_struct_array = np.asarray(gender_struct_list)
        else:
            total_gender_struct_array += np.asarray(gender_struct_list)
            
    total_male_count_array /= float(test_time)
    total_female_count_array /= float(test_time)
    total_extinct_rate_array /= float(test_time)
    total_age_struct_array /= float(test_time)
    total_gender_struct_array /= float(test_time)

    return total_male_count_array, total_female_count_array, total_extinct_rate_array, total_age_struct_array, total_gender_struct_array


def batch_test(start_pop_num=30, pop_create_time=100, test_time=100, max_year=100, b_print=False):
    print('*********************************')
    print('* survivor rate of age 0: {}'.format(SURVIVOR_RATE_MAP[0]))
    print('* start_pop_num: {}'.format(start_pop_num))
    print('* pop_create_time: {}'.format(pop_create_time))
    print('* test_time: {}'.format(test_time))
    print('* max_year: {}'.format(max_year))
    print('*********************************')
    total_male_count_array = np.zeros(max_year)
    total_female_count_array = np.zeros(max_year)
    total_extinct_rate_array = np.zeros(max_year)
    total_age_struct_array = None
    total_gender_struct_array = None
    all_last_extinct_rate_array = np.zeros(max_year)
    
    for i in tqdm(range(pop_create_time)):
        male_count_array, female_count_array, extinct_rate_array, age_struct_array, gender_struct_array = test(start_pop_num=start_pop_num, test_time=test_time, max_year=max_year, b_print=b_print)
        total_male_count_array += male_count_array
        total_female_count_array += female_count_array
        total_extinct_rate_array += extinct_rate_array
        if total_age_struct_array is None:
            total_age_struct_array = age_struct_array
        else:
            total_age_struct_array += age_struct_array
        if total_gender_struct_array is None:
            total_gender_struct_array = gender_struct_array
        else:
            total_gender_struct_array += gender_struct_array
        all_last_extinct_rate_array[i] = extinct_rate_array[-1]

    total_male_count_array /= float(pop_create_time)
    total_female_count_array /= float(pop_create_time)
    total_extinct_rate_array /= float(pop_create_time)
    total_age_struct_array /= float(pop_create_time)
    total_gender_struct_array /= float(pop_create_time)

    df = pd.DataFrame()

    mean_last_extinct_rate_array = np.mean(all_last_extinct_rate_array)
    max_last_extinct_rate_array = np.max(all_last_extinct_rate_array)
    min_last_extinct_rate_array = np.min(all_last_extinct_rate_array)
    std_last_extinct_rate_array = np.std(all_last_extinct_rate_array)

    df = pd.DataFrame.from_dict({'mean': [mean_last_extinct_rate_array], 'min': [min_last_extinct_rate_array], 'max': [max_last_extinct_rate_array], 'std': [std_last_extinct_rate_array]})
    df.to_csv('E:/extinct_rate.csv')
    df = pd.DataFrame(all_last_extinct_rate_array)
    df.to_csv('E:/extinct_rate_array.csv')


if __name__ == '__main__':
    batch_test(start_pop_num=10, pop_create_time=100, test_time=500, max_year=100, b_print=False)



