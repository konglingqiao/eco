from enum import Enum

class GiantPanda:
    def __init__(self, age, gender):
        self.age = age
        self.gender = gender
        self.alive = True